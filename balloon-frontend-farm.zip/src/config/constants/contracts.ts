export default {
  cake: {
    56: '0x55c0bf68101fd8c0f56461df2732e358c2c6d0b2',
    97: '',
  },
  masterChef: {
    56: '0xff4735e3f45c2f004b48a9cbd708262b4399c0f1',
    97: '',
  },
  wbnb: {
    56: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
    97: '',
  },
  mulltiCall: {
    56: '0x1ee38d535d541c55c9dae27b12edf090c608e6fb',
    97: '0x67ADCB4dF3931b0C5Da724058ADC2174a9844412',
  },
  busd: {
    56: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
    97: '0xed24fc36d5ee211ea25a80239fb8c4cfd80f12ee',
  },
}
